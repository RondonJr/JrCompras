export class Categoria {
    id: number;
    categoria_name: string;
}
