export class Produto {
    id: number;
    produto_name: string;
    unidadeid: number;
    categoriaid: number;
    quantidade: number;
}
