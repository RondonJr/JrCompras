import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-categoria',
  templateUrl: './edit-categoria.page.html',
  styleUrls: ['./edit-categoria.page.scss'],
})
export class EditCategoriaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
