import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-produto',
  templateUrl: './edit-produto.page.html',
  styleUrls: ['./edit-produto.page.scss'],
})
export class EditProdutoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
